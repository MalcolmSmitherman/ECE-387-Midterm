Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/simpletest.py
    :caption: examples/simpletest.py
    :linenos:
